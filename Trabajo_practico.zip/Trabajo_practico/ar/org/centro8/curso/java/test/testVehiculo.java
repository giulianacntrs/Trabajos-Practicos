package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;



public class testVehiculo {
    public static void main(String[] args) {
    System.out.println("-------1.Auto Clásico------");
    AutoClasico auto1 = new AutoClasico("Azul", "Chevrolet", "Chevy");
    System.out.println(auto1);  
    System.out.println("----Con radio agregada----");  
    auto1.setRadio("RetroSound Laguna Radio AM/FM AUX");  
    System.out.println(auto1);
    System.out.println(auto1.getRadio());
    System.out.println("--------Con precio---------");
    System.out.println(auto1);
    System.out.println(auto1.getRadio());
    auto1.setPrecio(10.178101);
    System.out.println("\n");

    System.out.println("-------1.Auto Nuevo------");
    AutoNuevo auto2 = new AutoNuevo("Negro", "Peugeot", "206", "clarion cz209");
    System.out.println(auto2);
    System.out.println(auto2.getRadio());
    System.out.println("-------Cambio de radio------");
    System.out.println(auto2);
    auto2.setRadio("Stromberg Carlson SC-6003");
    System.out.println(auto2.getRadio());
    System.out.println("-------Con precio------");
    System.out.println(auto2);
    auto2.setPrecio(1488000);
    System.out.println("\n");
    
    System.out.println("-------2.Auto Clásico------");
    AutoClasico auto3 = new AutoClasico("Rojo", "Renault", "Torino");
    System.out.println(auto3);
    System.out.println("----Con radio agregada----"); 
    auto3.setRadio("RetroSound Laguna Radio AM/FM");
    System.out.println(auto3);
    System.out.println(auto3.getRadio());
    System.out.println("--------Con precio---------");
    System.out.println(auto3);
    System.out.println(auto3.getRadio());
    auto3.setPrecio(2.872101);
    System.out.println("\n");

    System.out.println("-------2.Auto Nuevo------");
    AutoNuevo auto4 = new AutoNuevo("Gris", "Toyota", "Corolla 207", " KUNFINE Android car stereo");
    System.out.println(auto4);
    System.out.println(auto4.getRadio());
    System.out.println("-------Cambio de radio------");
    System.out.println(auto4);
    auto2.setRadio("Eunavi Android 10 car stereo ");
    System.out.println(auto4.getRadio());
    System.out.println("-------Con precio------");
    System.out.println(auto4);
    auto2.setPrecio(3.018825);
       

}
}
