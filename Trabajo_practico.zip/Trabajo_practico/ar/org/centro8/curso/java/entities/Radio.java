package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.utils.ColoresAnsi;

public class Radio {
private String marcaRadio;


public Radio (String marcaRadio) {this.marcaRadio = marcaRadio;}

@Override
public String toString() {return  ColoresAnsi.ANSI_RED +"MARCA RADIO = " + marcaRadio + ColoresAnsi.ANSI_RESET;}
}
    

