package ar.org.centro8.curso.java.entities;
import ar.org.centro8.curso.java.utils.ColoresAnsi;

public class Vehiculo {
    private String color;
    private String marca;
    private String modelo;
    private double precio;
    private Radio radio;
    
    
    public Vehiculo(String color, String marca, String modelo) {this.color = color; 
        this.marca = marca; 
        this.modelo = modelo;}

    public Vehiculo(String color, String marca, String modelo, String marcaRadio)
     {
        this.color = color; 
        this.marca = marca;
        this.modelo = modelo; 
        this.radio = new Radio(marcaRadio); }

    @Override
    public String toString() {
        return (ColoresAnsi.ANSI_GREEN+"COLOR = " + color+ColoresAnsi.ANSI_RESET) + (ColoresAnsi.ANSI_PURPLE + " \nMARCA = " + marca +ColoresAnsi.ANSI_RESET) + 
        (ColoresAnsi.ANSI_YELLOW +" \nMODELO = " + modelo +ColoresAnsi.ANSI_RESET);}

    public String getColor() {
        return color;  }

    public void setColor(String color) {
        this.color = color;}

    public String getMarca() {
        return marca; }

    public void setMarca(String marca) {
        this.marca = marca; }

    public String getModelo() {
        return modelo; }

    public void setModelo(String modelo) {
        this.modelo = modelo; }

    public double getPrecio() {
        return precio;}

    public void setPrecio(double precio) {
        this.precio = precio;
        if(this.precio==0.0){System.out.println(ColoresAnsi.ANSI_CYAN+"PRECIO = A CONSULTAR"+ColoresAnsi.ANSI_RESET);}
        else {System.out.println(ColoresAnsi.ANSI_CYAN+"PRECIO = $"+ precio +ColoresAnsi.ANSI_RESET); }}


    public Radio getRadio() {
        return radio;}

    public void setRadio(String marcaRadio) {
        this.radio = new Radio(marcaRadio);}
}

