package ar.org.centro8.curso.java.entities;

public class AutoClasico extends Vehiculo{

    public AutoClasico(String color, String marca, String modelo) {super(color, marca, modelo);}

    public AutoClasico(String color, String marca, String modelo,String marcaRadio, Radio radio) {super(color, marca, modelo,marcaRadio);}}
